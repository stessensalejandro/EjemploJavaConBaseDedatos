import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.CallableStatement;

import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.awt.event.ActionEvent;

public class TransferenciaVentana extends JFrame {

	private JPanel contentPane;
	private JTextField tNumeroCajaDeAhorro;
	private JTextField tMonto;
	private final JLabel lblNewLabel = new JLabel("Numero Caja de Ahorro Destino");
	private final JButton bAceptar = new JButton("Aceptar");
	private final JButton btnCancelar = new JButton("Cancelar");
	private String numeroTarjeta;
	private Statement stmt;
	protected Connection conexionBD = null;
	private BaseDeDatos conectar;
	private String res;

	public TransferenciaVentana(String numeroTarjeta) {
		System.out.println("entro al constructor con numeroTarjeta " + numeroTarjeta);
		this.numeroTarjeta = numeroTarjeta;
		setTitle("Datos de Transferencia");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(420, 350, 450, 175);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		lblNewLabel.setBounds(0, 14, 199, 14);
		contentPane.add(lblNewLabel);

		tNumeroCajaDeAhorro = new JTextField();
		tNumeroCajaDeAhorro.setBounds(188, 11, 86, 20);
		contentPane.add(tNumeroCajaDeAhorro);
		tNumeroCajaDeAhorro.setColumns(10);

		JLabel lblMonto = new JLabel("Monto");
		lblMonto.setBounds(111, 39, 51, 14);
		contentPane.add(lblMonto);

		bAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				int dialogButton = 0;
				int dialogResult = JOptionPane.showConfirmDialog(null, "�Desea confirmar la transferencia?", "Warning",
						dialogButton);
				if (dialogResult == JOptionPane.YES_OPTION) {
					// Saving code here
					hacerTransferencia();
				}
			}
		});
		bAceptar.setBounds(58, 68, 91, 23);
		contentPane.add(bAceptar);

		tMonto = new JTextField();
		tMonto.setBounds(188, 36, 86, 20);
		contentPane.add(tMonto);
		tMonto.setColumns(10);
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnCancelar.setBounds(183, 68, 99, 23);
		contentPane.add(btnCancelar);

		ConectarAlaBD();
	}

	private void hacerTransferencia() {

		if (esNumero(tMonto.getText()) && (esEntero(tNumeroCajaDeAhorro.getText())))
	     {
		
		
		int cajaDestino = Integer.parseInt(tNumeroCajaDeAhorro.getText());
		float montoATransferir = Float.parseFloat(tMonto.getText());

		int nt = Integer.parseInt(numeroTarjeta);

		System.out.println("empieza el hacer transferencia: ");

		//CallableStatement stmt2 = null;
		
		Statement stmt2=null;
		try {
			stmt2 = conexionBD.createStatement();
		} catch (SQLException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}						
	
		
		ResultSet rs2 = null;
			 String res=null;
			 
			try {
				rs2= stmt2.executeQuery("{call transferenciaACajaDeAhorro(" + nt + "," + cajaDestino + ",10," + montoATransferir + ")} ");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			try {
	    	 
	    	 
			while(rs2.next()){
			       res=rs2.getString(1);
			   }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),e,"Mensaje de error",JOptionPane.ERROR_MESSAGE);
	    
		}
		
			
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),res,"Mensaje de informacion",JOptionPane.INFORMATION_MESSAGE);
	     	
		 
		//} 
		//catch (SQLException e1) {
			// TODO Auto-generated catch block
		//	JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),"La operacion se ha realizado con exito","Mensaje exitoso",JOptionPane.INFORMATION_MESSAGE);
			
			
			
	//	}
	     }
	     
		
		else 
		{
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),"Ingrese un valor num�rico en cada campo","Mensaje error",JOptionPane.ERROR_MESSAGE);
				
		}
	
		tNumeroCajaDeAhorro.setText("");
		tMonto.setText("");
	
	}
	
	
	public boolean esNumero(String cadena) {

        boolean resultado;

        try {
            Float.parseFloat(cadena);
            resultado = true;
        } catch (NumberFormatException excepcion) {
            resultado = false;
        }

        return resultado;
    }
	
	public boolean esEntero(String cadena) {

        boolean resultado;

        try {
            Integer.parseInt(cadena);
            resultado = true;
        } catch (NumberFormatException excepcion) {
            resultado = false;
        }

        return resultado;
    }



	private void ConectarAlaBD() {
		System.out.println("se mete al m�todo para conectar");

		conectar = new BaseDeDatos(null);
		conectar.conectarBaseDatos("atm", "atm");
		conexionBD = conectar.conexion();

	}
}
