import java.text.ParseException;
import java.text.SimpleDateFormat;


public class Fecha {

	public static java.util.Date convertirCadenaAFecha(String cadenaAconvertir) {
		java.util.Date resultado = null;
		if (cadenaAconvertir != null) {
			try {
				resultado = (new SimpleDateFormat("dd/MM/yyyy")).parse(cadenaAconvertir);
			} catch (ParseException ex) {
				System.out.println(ex.getMessage());
			}
		}
		return resultado;
	}

	public static java.sql.Date convertirFechaAFechaSQL(java.util.Date fechaAconvertir) {
		java.sql.Date resultado = null;
		if (fechaAconvertir != null) {
			resultado = java.sql.Date.valueOf((new SimpleDateFormat("yyyy-MM-dd")).format(fechaAconvertir));
		}
		return resultado;
	}

	
}
