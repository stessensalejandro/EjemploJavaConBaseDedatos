
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import quick.dbtable.DBTable;

//Clase encargada de manejar las conexiones con la base de datos.

public class BaseDeDatos {
	private Connection conexionBD = null;

	public BaseDeDatos(DBTable tabla) {

	}

	/**
	 * Dados un usuario y una clave, intenta realizar una conexion con el
	 * servidor.
	 * 
	 * @param contrase�a
	 *            del usuario
	 * @param nombre
	 *            de usuario
	 */
	public void conectarBaseDatos(String clave, String usuario) {
		try {
			String servidor = "localhost:3306";
			String baseDatos = "banco";
			String uriConexion = "jdbc:mysql://" + servidor + "/" + baseDatos
					+ "?useSSL=false&allowPublicKeyRetrieval=true";

			this.conexionBD = DriverManager.getConnection(uriConexion, usuario, clave);
			System.out.println("conecto con usuario " + usuario);
		} catch (SQLException ex) {

			System.out.println("No conect� a la BD con usuario: " + usuario);
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}

	}

	/**
	 * Retorna la conexion con el servidor
	 * 
	 * @return conexionBD, conexion con el server
	 */
	public Connection conexion() {
		return conexionBD;
	}
}
