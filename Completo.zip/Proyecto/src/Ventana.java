
/**
 * Interfaz para los distintos tipos de logueo en la ventana de logueo.
 * 
 *
 */
public interface Ventana {
	/**
	 * Realiza la conexion del usuario con la base de datos.
	 * 
	 * @param clave
	 *            contrase�a del usuario.
	 * @param usuario
	 *            nombre del usuario.
	 * @return
	 */
	public boolean ingresarAlaBD(String clave, String usuario);
}
