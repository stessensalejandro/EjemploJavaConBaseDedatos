
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.plaf.basic.BasicLabelUI;
import javax.swing.JTextField;
import javax.swing.JLabel;
import quick.dbtable.DBTable;
import javax.swing.JScrollPane;

/**
 * Se encarga de las operaciones del atm.
 */
@SuppressWarnings("serial")
public class ATMVentana extends javax.swing.JInternalFrame implements Ventana {

	private BaseDeDatos conectar;
	protected Connection conexionBD = null;
	private SuscripcionVentana Login;
	private JPanel panelPrincipal;

	private DBTable tabla;
	private String tarjeta;
	private Statement stmt;
	private JTextField finicio;
	private JTextField ffin;
	private JButton bTransferencia;
	private JButton bExtraccion;
	private TransferenciaVentana tVentana;
	private ExtraccionVentana eVentana;

	/**
	 * Crea lo necesario para armar la ventana.
	 * 
	 * @param panel
	 */
	public ATMVentana(JPanel panel) {
		super();
		setTitle("Banco - ATM");
		initGUI();
		panelPrincipal = panel;

	}

	/**
	 * * Se encarga de armar la ventana del logueo del ATM.
	 */
	public void suscripcion() {
		Login = new SuscripcionVentana(this);
		Login.setBounds(170, 20, 650, 400);
		this.Login.setVisible(true);
		Login.setTitulo("Banco - ATM");
		Login.setPrimeraEtiqueta("Numero de Tarjeta");
		Login.setSegundaEtiqueta("Numero PIN");
		panelPrincipal.add(this.Login);
		try {
			Login.setSelected(true);
		} catch (PropertyVetoException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Inicializa la ventana para la Unidad ATM.
	 */
	private void initGUI() {
		try {

			// Armado de la ventana
			setPreferredSize(new Dimension(990, 475));
			this.setBounds(10, 50, 990, 475);
			setVisible(false);
			this.setClosable(true);
			this.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
			BorderLayout thisLayout = new BorderLayout();
			getContentPane().setLayout(thisLayout);

			getContentPane().setBackground(new Color(0, 204, 51));

			final JPanel panel = new JPanel();
			panel.setBounds(10, 50, 990, 475);
			panel.setBackground(new Color(0, 204, 51));
			panel.setForeground(new Color(0, 0, 0));
			getContentPane().add(panel);

			JButton bTransferencia = new JButton("Transferencia");
			bTransferencia.setBounds(790, 38, 151, 25);
			bTransferencia.setFont(new Font("Tahoma", Font.BOLD, 11));
			bTransferencia.setBackground(new Color(0, 204, 51));
			bTransferencia.setForeground(new Color(0, 0, 0));

			bTransferencia.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent arg0) {
					System.out.println("Presion� el boton transferencia ");
					tVentana = new TransferenciaVentana(tarjeta);

					System.out.println("tarjeta: " + tarjeta);

					tVentana.setVisible(true);

				}

			});

			JButton bExtraccion = new JButton("Extraccion");
			bExtraccion.setBounds(790, 97, 151, 25);
			bExtraccion.setFont(new Font("Tahoma", Font.BOLD, 11));
			bExtraccion.setBackground(new Color(0, 204, 51));
			bExtraccion.setForeground(new Color(0, 0, 0));
			bExtraccion.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent arg0) {
					System.out.println("Presion� el boton Extraccion");
					eVentana = new ExtraccionVentana(tarjeta);
					eVentana.setVisible(true);

				}

			});

			JButton UltimosMov = new JButton("Ultimos movimientos");
			UltimosMov.setBounds(26, 38, 191, 25);

			UltimosMov.setFont(new Font("Tahoma", Font.BOLD, 11));
			UltimosMov.setBackground(new Color(0, 204, 51));
			UltimosMov.setForeground(new Color(0, 0, 0));

			UltimosMov.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent arg0) {
					UltimasOperaciones();
				}

			});
			panel.setLayout(null);

			{
				// crea la tabla
				tabla = new DBTable();
				tabla.setBounds(130, 155, 760, 296);

				tabla.setBackground(new Color(0, 204, 51));
				panel.add(tabla);

				// setea la tabla para solo lectura
				tabla.setEditable(false);
			}
			panel.add(UltimosMov);
			panel.add(bTransferencia);
			panel.add(bExtraccion);

			JLabel fechafinal = new JLabel("Hasta (dia/mes/a�o)");
			fechafinal.setBounds(247, 74, 150, 16);
			panel.add(fechafinal);

			JScrollPane scrollPane_2 = new JScrollPane();
			scrollPane_2.setBounds(711, 227, 2, 2);
			panel.add(scrollPane_2);

			JPanel panel_1 = new JPanel();
			panel_1.setBounds(718, 223, 10, 10);
			panel.add(panel_1);

			JPanel panel_2 = new JPanel();
			panel_2.setBounds(733, 223, 10, 10);
			panel.add(panel_2);

			JLabel fechain = new JLabel("Desde (dia/mes/a�o)");
			fechain.setBounds(247, 9, 171, 16);
			panel.add(fechain);

			finicio = new JTextField();
			finicio.setBounds(247, 38, 139, 25);
			panel.add(finicio);
			finicio.setColumns(10);

			ffin = new JTextField();
			ffin.setBounds(247, 101, 139, 25);
			panel.add(ffin);
			ffin.setColumns(10);

			JButton operacionesEntreFechas = new JButton("Operaciones por periodo");

			operacionesEntreFechas.setBackground(new Color(0, 204, 51));
			operacionesEntreFechas.setForeground(new Color(0, 0, 0));
			operacionesEntreFechas.setBounds(486, 38, 221, 25);
			operacionesEntreFechas.addActionListener(new ActionListener() {

				public void actionPerformed(ActionEvent arg0) {
					OperacionesFecha();
					;
				}

			});
			panel.add(operacionesEntreFechas);

			JButton btnConsultarDatos = new JButton("Consulta de Saldo");

			btnConsultarDatos.setFont(new Font("Tahoma", Font.BOLD, 11));
			btnConsultarDatos.setBackground(new Color(0, 204, 51));
			btnConsultarDatos.setForeground(new Color(0, 0, 0));

			btnConsultarDatos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Saldo();
				}
			});
			btnConsultarDatos.setBounds(486, 97, 151, 25);
			panel.add(btnConsultarDatos);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Realiza la conexion del atm con la base de datos
	 */
	public boolean ingresarAlaBD(String clave, String usuario) {
		conectar = new BaseDeDatos(null);
		conectar.conectarBaseDatos("atm", "atm");

		conexionBD = conectar.conexion();

		String sql = "select * from Tarjeta";
		ResultSet rs = null;
		try {
			Statement stmt2 = this.conexionBD.createStatement();
			rs = stmt2.executeQuery(sql);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		try {
			if (rs.next()) {
				System.out.println("el atm puede consultar");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if (VerificarLogin(usuario, clave)) {
			this.Login.setVisible(false);
			this.setVisible(true);
			tarjeta = usuario;
			try {
				stmt = this.conexionBD.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			return true;
		} else
			return false;

	}
	
	public  boolean validar(String p_fecha) {
		if (p_fecha != null) {
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
				sdf.setLenient(false);
				sdf.parse(p_fecha);
				return true;
			} catch (ParseException ex) {
				}
		}
		return false;
	}


	/**
	 * Determina los movimientos del cliente de acuerdo a dos fechas ingresadas
	 */
	private void OperacionesFecha() {

		
		if (validar(finicio.getText()) && validar(ffin.getText())) 
		
		{
		if (ObtenerfechaCorrecta(finicio.getText()).compareTo(ObtenerfechaCorrecta(ffin.getText()))<=0)
		{
		
		
		if (finicio.getText() != null && ffin.getText() != null) {

			System.out.println(ObtenerfechaCorrecta(finicio.getText()));
			System.out.println(ObtenerfechaCorrecta(ffin.getText()));

		}
		String sql = "select fecha,hora,tipo,cod_caja,destino , if(tipo = 'deposito',monto , if(true,CONCAT('-',monto), \"true\")) as monto FROM "
				+ " tarjeta tarj INNER JOIN trans_cajas_ahorro  tran ON tarj.nro_ca = tran.nro_ca"
				+ " WHERE nro_tarjeta='" + tarjeta + "' and fecha between '" + ObtenerfechaCorrecta(finicio.getText())
				+ "' and '" + ObtenerfechaCorrecta(ffin.getText()) + "';";

		try {

			ResultSet rs = stmt.executeQuery(sql);

			// actualiza el contenido de la tabla con los datos del resul set rs
			tabla.refresh(rs);
			rs.close();
			if (tabla.getColumnByDatabaseName("hora") != null) {
				tabla.getColumnByDatabaseName("hora").setDateFormat("hh:mm:ss");
				tabla.getColumnByDatabaseName("hora").setMinWidth(80);
			}
			if (tabla.getColumnByDatabaseName("fecha") != null) {
				tabla.getColumnByDatabaseName("fecha").setDateFormat("dd/MM/YYYY");
				tabla.getColumnByDatabaseName("fecha").setMinWidth(80);
			}

			else {

				System.out.println("no llega a hacer la consulta");
				stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "Se modificaron datos \n",
						"Cambios en la BD", JOptionPane.INFORMATION_MESSAGE);

			}
		} catch (SQLException ex) {

			// en caso de error, se muestra en consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Error al ejecutar la consulta o ejecutado un insert.", JOptionPane.INFORMATION_MESSAGE);
		}
		
		}
	
		else
		{
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "La fecha de inicio debe ser menor que la de final" + "\n",
					"Error", JOptionPane.ERROR_MESSAGE);
		}
		}
		
		else
		{
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "Formato de fecha erroneo" + "\n",
					"Error", JOptionPane.ERROR_MESSAGE);
		}
		
		
		}
		
		
	


	/**
	 * conviente la fecha de un String a un una date de sql
	 * 
	 * @param fecha
	 *            fecha a convertir .
	 * @return fecha en formato sql
	 */
	private java.sql.Date ObtenerfechaCorrecta(String fecha) {

		Fecha fe = new Fecha();
		return fe.convertirFechaAFechaSQL(fe.convertirCadenaAFecha(fecha));

	}

	/**
	 * 
	 * Determina el saldo de la cuenta del cliente
	 */
	private void Saldo() {

		String sql = "select nro_ca,saldo from Caja_ahorro NATURAL JOIN Tarjeta WHERE nro_tarjeta= " + tarjeta + ";";

		try {

			ResultSet rs = stmt.executeQuery(sql);

			// actualiza el contenido de la tabla con los datos del resul set rs

			tabla.refresh(rs);
			rs.close();
			if (tabla.getColumnByDatabaseName("hora") != null) {
				tabla.getColumnByDatabaseName("hora").setDateFormat("hh:mm:ss");
				tabla.getColumnByDatabaseName("hora").setMinWidth(80);
			}
			if (tabla.getColumnByDatabaseName("fecha") != null) {
				tabla.getColumnByDatabaseName("fecha").setDateFormat("dd/MM/YYYY");
				tabla.getColumnByDatabaseName("fecha").setMinWidth(80);
			}

			else {

				stmt.execute(sql);

			}
		} catch (SQLException ex) {

			// en caso de error, se muestra la causa en la consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Error al ejecutar la consulta o a ejecutado un insert.", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	/**
	 * Determina los movimientos del cliente
	 */
	private void UltimasOperaciones() {
		try {
			String sql = "select fecha,hora,tipo,cod_caja,destino , if(tipo = 'deposito',monto , if(true,CONCAT('-',monto), \"true\")) as monto FROM "
					+ " tarjeta tarj INNER JOIN trans_cajas_ahorro  tran ON tarj.nro_ca = tran.nro_ca"
					+ " WHERE nro_tarjeta='" + tarjeta + "';";

			;
			ResultSet rs = stmt.executeQuery(sql);
			tabla.refresh(rs);
			// actualiza el contenido de la tabla con los datos del resul set rs
			rs.close();
			if (tabla.getColumnByDatabaseName("hora") != null) {
				tabla.getColumnByDatabaseName("hora").setDateFormat("hh:mm:ss");
				tabla.getColumnByDatabaseName("hora").setMinWidth(80);
			}
			if (tabla.getColumnByDatabaseName("fecha") != null) {
				tabla.getColumnByDatabaseName("fecha").setDateFormat("dd/MM/YYYY");
				tabla.getColumnByDatabaseName("fecha").setMinWidth(80);
			}

			else {

				stmt.executeUpdate(sql);

				JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "Se modificaron datos \n",
						"Cambios en la BD", JOptionPane.INFORMATION_MESSAGE);

			}
		} catch (SQLException ex) {

			// en caso de error, se muestra en consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Error al ejecutar la consulta o ejecutado un insert.", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	/**
	 * Verifica si los datos de logueo de la tarjeta son correctos.
	 * 
	 * @param usuario
	 *            nombre de usuario.
	 * @param clave
	 *            contrase�a del usuario.
	 * @return true si se pudo conectar, falso caso contrario.
	 */
	private boolean VerificarLogin(String usuario, String clave) {
		boolean verificado = false;
		try {
			Statement stmt = this.conexionBD.createStatement();
			String sql = "select * from tarjeta where nro_tarjeta=" + usuario + " and PIN=" + "md5('" + clave + "')";
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				verificado = true;
				System.out.println("la consulta tiene resultados");
			}
		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Contrase�a o usuario invalido.", JOptionPane.ERROR_MESSAGE);
		}
		return verificado;

	}

}
