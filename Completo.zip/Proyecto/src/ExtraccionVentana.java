import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import com.mysql.jdbc.CallableStatement;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import java.awt.FlowLayout;
import javax.swing.JButton;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ExtraccionVentana extends JFrame {

	private JPanel contentPane;
	private JTextField tMonto;
	private String numeroTarjeta;
	private Statement stmt;
	protected Connection conexionBD = null;
	private BaseDeDatos conectar;

	/**
	 * Launch the application.
	 */
	public ExtraccionVentana(String nTarjeta) {
		numeroTarjeta = nTarjeta;
		setTitle("Datos de Extraccion");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(420, 350, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int dialogButton = 0;
				int dialogResult = JOptionPane.showConfirmDialog(null, "�Desea confirmar la Extraccion?", "Warning",
						dialogButton);
				if (dialogResult == JOptionPane.YES_OPTION) {
					// Saving code here
					hacerExtraccion();

				}

			}
		});
		btnAceptar.setBounds(157, 42, 82, 23);
		contentPane.add(btnAceptar);

		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancelar.setBounds(249, 42, 99, 23);
		contentPane.add(btnCancelar);

		JLabel lblMonto = new JLabel("Monto");
		lblMonto.setBounds(89, 14, 59, 14);
		contentPane.add(lblMonto);

		tMonto = new JTextField();
		tMonto.setBounds(157, 11, 86, 20);
		contentPane.add(tMonto);
		tMonto.setColumns(10);

		ConectarAlaBD();
	}

	private void hacerExtraccion() {

		if (esNumero(tMonto.getText()))
	     {
		
		float montoATransferir = Float.parseFloat(tMonto.getText());

		int nt = Integer.parseInt(numeroTarjeta);

		System.out.println("empieza el hacer extraccion: ");

		//CallableStatement stmt2 = null;
		Statement stmt2 = null;
		
		//try {
			try {
				
				stmt2 =conexionBD.createStatement();						
			
				
				//stmt2 = (CallableStatement) conexionBD
				//		.prepareCall("{call extraerDeCajaDeAhorro(" + nt + ",10," + montoATransferir + ")} ");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			String res=null;
		ResultSet rs2 = null;
		try {
			rs2 = stmt2.executeQuery("call extraerDeCajaDeAhorro(" + nt + ",10," + montoATransferir + ")");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	     try {
			while(rs2.next()){
			       res=rs2.getString(1);
			   }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),e,"Mensaje de error",JOptionPane.ERROR_MESSAGE);
			
		}
		    
	     
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),res,"Mensaje",JOptionPane.INFORMATION_MESSAGE);
		
		 
		//}
		// catch (SQLException e1) {
			// TODO Auto-generated catch block
			//JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),"La operacion se ha realizado con exito","Mensaje exitoso",JOptionPane.INFORMATION_MESSAGE);
		
		//}
		
		}
		
		else
		{
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),"Ingrese un valor num�rico","Mensaje e",JOptionPane.ERROR_MESSAGE);
			
		}
		
			
	tMonto.setText("");
	}

	 public boolean esNumero(String cadena) {

	        boolean resultado;

	        try {
	            Float.parseFloat(cadena);
	            resultado = true;
	        } catch (NumberFormatException excepcion) {
	            resultado = false;
	        }

	        return resultado;
	    }

	
	private void ConectarAlaBD() {
		System.out.println("se mete al m�todo para conectar");

		conectar = new BaseDeDatos(null);
		conectar.conectarBaseDatos("atm", "atm");
		conexionBD = conectar.conexion();

	}

}
