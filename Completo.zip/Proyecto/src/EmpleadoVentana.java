import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

//import lib.TablaBD;

import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.JLabel;

import quick.dbtable.DBTable;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.border.LineBorder;
import java.awt.Color;

/**
 * Se encarga de todo lo relacionado a la ventana de operaciones del empleado y
 * las operaciones que realiza.
 */
@SuppressWarnings("serial")
public class EmpleadoVentana extends javax.swing.JInternalFrame implements Ventana {

	private SuscripcionVentana Login;
	private int nro_prestamo;
	private JPanel panelPrincipal;
	private BaseDeDatos conectar;
	protected Connection conexionBD = null;
	private DBTable tabla;
	private Statement stmt;
	private JTextField NroDoc;
	private JTextField TipoDoc;
	private String legajo;
	private JLabel lblMonto;
	private JTextField montotf;
	private JScrollPane scrollPane;
	private JScrollPane scrollPane_1;
	private String cliente;
	private JButton btnGeneraPrestamo;
	private String totalPrestamos;
	private JTextField textField;
	private JList listaDeCuotas;

	/**
	 * Crea lo necesario para armar la ventana.
	 * 
	 * @param panel
	 */
	public EmpleadoVentana(JPanel panel) {
		super();
		setTitle("Banco - Prestamos");
		initGUI();
		panelPrincipal = panel;

	}

	/**
	 * Se encarga de armar la ventana del logueo del empleado.
	 */
	public void suscripcion() {
		Login = new SuscripcionVentana(this);
		Login.setBounds(170, 20, 650, 400);
		this.Login.setVisible(true);
		Login.setTitulo("Banco - Login Empleado");
		Login.setPrimeraEtiqueta("Numero de Legajo");
		Login.setSegundaEtiqueta("Password");
		panelPrincipal.add(this.Login);
		try {
			Login.setSelected(true);
		} catch (PropertyVetoException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Inicializa la ventana para el empleado.
	 */
	private void initGUI() {
		try {

			// Armado de la ventana
			setPreferredSize(new Dimension(990, 475));
			this.setBounds(10, 50, 990, 475);
			setVisible(false);
			this.setClosable(true);
			this.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
			this.setMaximizable(true);
			BorderLayout thisLayout = new BorderLayout();
			getContentPane().setLayout(thisLayout);

			{
				scrollPane = new JScrollPane();
				scrollPane.setBounds(389, 56, 98, 111);

				getContentPane().add(scrollPane);

				final JPanel panel = new JPanel();
				scrollPane.setViewportView(panel);
				panel.setBounds(10, 22, 522, 271);

				panel.setLayout(null);

				{
					// crea la tabla
					tabla = new DBTable();
					tabla.setBounds(45, 299, 727, 152);
					panel.add(tabla);

					// setea la tabla para solo lectura (no se puede editar su
					// contenido)
					tabla.setEditable(false);
				}

				JScrollPane paneJS = new JScrollPane();
				paneJS.setBounds(711, 227, 2, 2);
				panel.add(paneJS);

				JPanel panel_1 = new JPanel();

				panel.setFont(new Font("Tahoma", Font.BOLD, 11));
				// panel.setBackground(new Color(0, 204, 51));
				// panel.setForeground(new Color(0, 0, 0));

				panel_1.setBounds(718, 223, 10, 10);
				panel.add(panel_1);

				JPanel panel_2 = new JPanel();
				panel_2.setBounds(733, 223, 10, 10);
				panel.add(panel_2);

				JButton btnGenerarPrestamo = new JButton("Verificar Prestamo");

				btnGenerarPrestamo.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnGenerarPrestamo.setBackground(new Color(0, 204, 51));
				btnGenerarPrestamo.setForeground(new Color(0, 0, 0));

				btnGenerarPrestamo.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						if (puedeGenerarPrestamo()) {
							lblMonto.setVisible(true);
							montotf.setVisible(true);
							btnGeneraPrestamo.setVisible(true);
							btnGeneraPrestamo.setFont(new Font("Tahoma", Font.BOLD, 11));
							JOptionPane.showMessageDialog(null,
									"El cliente puede generar prestamos");


						} else
							JOptionPane.showMessageDialog(null,
									"El cliente tiene prestamos pendientes o bien no existe un cliente con esos datos");

					}
				});
				btnGenerarPrestamo.setBounds(11, 227, 132, 25);
				panel.add(btnGenerarPrestamo);

				montotf = new JTextField();
				montotf.setBounds(219, 68, 132, 25);
				panel.add(montotf);
				montotf.setColumns(10);
				montotf.setVisible(false);

				lblMonto = new JLabel("Monto ");
				lblMonto.setBounds(219, 41, 56, 16);
				panel.add(lblMonto);
				lblMonto.setVisible(false);

				btnGeneraPrestamo = new JButton("Generar Prestamo");

				btnGeneraPrestamo.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnGeneraPrestamo.setBackground(new Color(0, 204, 51));
				btnGeneraPrestamo.setForeground(new Color(0, 0, 0));

				btnGeneraPrestamo.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						IntroducirMonto();
					}

				});
				btnGeneraPrestamo.setBounds(219, 118, 152, 25);
				panel.add(btnGeneraPrestamo);

				scrollPane_1 = new JScrollPane();
				scrollPane_1.setBounds(224, 154, 96, 91);
				panel.add(scrollPane_1);
				{
					listaDeCuotas = new JList();
					scrollPane_1.setViewportView(listaDeCuotas);
					scrollPane_1.setFont(new Font("Tahoma", Font.BOLD, 11));
					scrollPane_1.setBackground(new Color(0, 204, 51));
					scrollPane_1.setForeground(new Color(0, 0, 0));
				}

				btnGeneraPrestamo.setVisible(false);
				JButton btnCuotasImpagas = new JButton("Cuotas Impagas");

				btnCuotasImpagas.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnCuotasImpagas.setBackground(new Color(0, 204, 51));
				btnCuotasImpagas.setForeground(new Color(0, 0, 0));

				btnCuotasImpagas.setBounds(413, 71, 139, 23);

				btnCuotasImpagas.addActionListener(new ActionListener() {

					public void actionPerformed(ActionEvent arg0) {
						
						
						MostrarCuotasImpagas();
						
					}

				});

				panel.add(btnCuotasImpagas);

				JButton btnPagarCuotas = new JButton("Pagar Cuotas");

				btnPagarCuotas.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnPagarCuotas.setBackground(new Color(0, 204, 51));
				btnPagarCuotas.setForeground(new Color(0, 0, 0));

				btnPagarCuotas.setBounds(413, 133, 139, 23);
				btnPagarCuotas.addActionListener(new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent arg0) {
							abonarCuotas();
						}
						
					
				});

				panel.add(btnPagarCuotas);

				JButton btnListadoDeMorosos = new JButton("Clientes Morosos");

				btnListadoDeMorosos.setFont(new Font("Tahoma", Font.BOLD, 11));
				btnListadoDeMorosos.setBackground(new Color(0, 204, 51));
				btnListadoDeMorosos.setForeground(new Color(0, 0, 0));

				btnListadoDeMorosos.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						mostrarMorosos();
					}
				});
				btnListadoDeMorosos.setBounds(413, 200, 165, 23);
				panel.add(btnListadoDeMorosos);

				JPanel panel_3 = new JPanel();
				panel_3.setBorder(new LineBorder(new Color(0, 0, 0)));
				panel_3.setBounds(11, 21, 147, 167);
				panel.add(panel_3);
				panel_3.setLayout(null);

				JLabel lblDatosDelCliente = new JLabel("Datos del cliente");
				lblDatosDelCliente.setBounds(12, 11, 110, 14);
				panel_3.add(lblDatosDelCliente);

				JLabel lblTipoDeDocumento = new JLabel("Numero de Documento");
				lblTipoDeDocumento.setBounds(10, 46, 112, 14);
				panel_3.add(lblTipoDeDocumento);

				NroDoc = new JTextField();
				NroDoc.setBounds(10, 71, 112, 20);
				panel_3.add(NroDoc);
				NroDoc.setColumns(10);

				JLabel lblNumeroDeDocumento = new JLabel("Tipo de Documento");
				lblNumeroDeDocumento.setBounds(10, 102, 150, 16);
				panel_3.add(lblNumeroDeDocumento);

				TipoDoc = new JTextField();
				TipoDoc.setBounds(6, 129, 116, 25);
				panel_3.add(TipoDoc);
				TipoDoc.setColumns(10);
				btnGeneraPrestamo.setVisible(false);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 
	 * Determina la cantidad de cuotas y el interes de acuerdo al monto
	 */

	/**
	 * Genera un prestamo nuevo
	 * 
	 * @param c
	 *            cantidad de cuotas del prestamo.
	 * @param montoCadena
	 *            monto del prestamo.
	 */
	public void a�adirPrestamo(String c, String montoCadena) {
		if (puedeGenerarPrestamo()) {
			try {
				String sql = "select tasa from Tasa_Prestamo where periodo=" + c + " and monto_inf<='" + montoCadena
						+ "' and monto_sup>='" + montoCadena + "';";
				ResultSet rs = stmt.executeQuery(sql);

				if (rs.next()) {
					String num = NroDoc.getText();
					String tipo = TipoDoc.getText();

					// obtengo datos de tasa para generar prestamo

					float tasa = rs.getFloat(1);
					int periodo = Integer.parseInt(c);
					int monto = Integer.parseInt(montoCadena);
					float valorinteres = (monto * tasa * periodo) / 1200;
					float valorCuota = (monto + valorinteres) / periodo;

					String cliente = Obtenercliente(num, tipo);
					rs.close();

					String insertaPrestamo = "INSERT INTO Prestamo VALUES(null,CURDATE()," + periodo + "," + monto
							+ " ," + tasa + " ," + valorinteres + " ," + valorCuota + "," + legajo + "," + cliente
							+ ")";
					stmt.execute(insertaPrestamo);

					JOptionPane.showMessageDialog(null, "Se creo un nuevo prestamo");

				}

			} catch (SQLException ex) {

				// se muestra si hay error al cargar el prestamo en la consola
				JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
						"Error al agregar prestamo.", JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}

	/**
	 * Calcula las de acuerdo al periodo para el prestamo ingresado
	 * 
	 * @param periodo
	 *            cantidad de cuotas.
	 * @param prestamo
	 *            numero del prestamo al que se le van a generar cuotas.
	 */
	public void calcularCuotas(int periodo, String prestamo) {
		try {

			String sql = "select adddate(curdate(),interval 1 month) as fechamodificada";
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				String fecha = rs.getString("fechamodificada");
				rs.close();

				int generador = 1;
				while (generador <= periodo) {

					String sql3 = "INSERT INTO Pago VALUES(" + prestamo + "," + generador + ",adddate('" + fecha
							+ "', interval 1 month),null);";

					String sql2 = "select adddate('" + fecha + "',interval 1 month) as fechamodificada;";
					ResultSet rs2 = stmt.executeQuery(sql2);
					if (rs2.next()) {

						fecha = rs2.getString("fechamodificada");
						stmt.execute(sql3);
					}

					rs2.close();
					generador = generador + 1;

				}

			}

		} catch (SQLException ex) {

			// se muestra si hay error al crear cuotas
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Error al crear cuotas.", JOptionPane.INFORMATION_MESSAGE);
		}
	}

	/**
	 * determina si un cliente puede sacar un prestamo , esto es si para todo
	 * prestamo del cliente estan pagas
	 * 
	 * @return true si el cliente puede sacar un prestamo,falso de caso
	 *         contrario
	 */
	public boolean puedeGenerarPrestamo() {

		boolean puede = false;
		System.out.println("numero doc del cliente " + NroDoc.getText());

		try {
			// if (!NroDoc.getText().equals("") &&
			// !TipoDoc.getText().equals("")) {

			System.out.println("numero doc del cliente " + NroDoc.getText());
			System.out.println("tipo de doc del cliente " + TipoDoc.getText());
			String num = NroDoc.getText();
			String tipo = TipoDoc.getText();
			cliente = Obtenercliente(num, tipo);

			if (cliente != null) {
				String sql = "SELECT nro_pago, fecha_pago,nro_doc"

						+ " FROM prestamo natural join pago natural join cliente" + " where nro_doc='" + num
						+ "' and tipo_doc='" + tipo + "';";
				ResultSet rs = stmt.executeQuery(sql);
				puede = true;
				if (rs.next()) {

					rs.beforeFirst();
					while (rs.next()) {
						if (rs.getString("fecha_pago") == null)
							puede = false;
					}
				}
				rs.close();
			} else {
				JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "cliente inexistente" + "\n",
						"error", JOptionPane.ERROR_MESSAGE);

			}

			// }
		} catch (SQLException ex) {

			// en caso de error, se muestra la causa en la consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
					"Los datos del cliente son incorrectos" + "\n", "error", JOptionPane.INFORMATION_MESSAGE);
		}

		return puede;

	}

	/**
	 * Determina el num cliente de acuerdo al documento y tipo
	 * 
	 * @param num
	 *            numero de documento.
	 * @param tipo
	 *            tipo de documento.
	 * @return numero de cliente
	 */
	public String Obtenercliente(String num, String tipo) {
		String cliente;
		try {
			String sql = "SELECT nro_cliente" + " FROM cliente" + " where nro_doc='" + num + "' and tipo_doc='" + tipo
					+ "'";
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) {
				cliente = rs.getString("nro_cliente");
				return cliente;
			}
		} catch (SQLException ex) {

			// en caso de error, se muestra la causa en la consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"No se pudo obtener el cliente.", JOptionPane.INFORMATION_MESSAGE);
		}
		return null;
	}

	/**
	 * Corrobora si los datos de logueo del empleado son correctos.
	 * 
	 * @param usuario
	 *            nombre de usuario.
	 * @param clave
	 *            contrase�a del usuario.
	 * @return true si se pudo conectar, falso caso contrario.
	 */
	public boolean verificarLogin(String usuario, String clave) {
		System.out.println("usuario: " + usuario);
		System.out.println("clave: " + clave);

		boolean verificado = false;
		try {
			Statement stmt = this.conexionBD.createStatement();
			String sql = "select * from Empleado where legajo=" + usuario + " and password=" + "md5('" + clave + "')";
			ResultSet rs = stmt.executeQuery(sql);
			if (rs.next()) // compruebo si la consulta dio resultados
			{
				System.out.println("tiene resultados la consulta");

				verificado = true;
			}

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Contrase�a o usuario invalido.", JOptionPane.ERROR_MESSAGE);
		}
		return verificado;
	}

	/**
	 * Realiza la conexion del empleado con la base de datos
	 */
	public boolean ingresarAlaBD(String clave, String usuario) {
		conectar = new BaseDeDatos(null);
		conectar.conectarBaseDatos("empleado", "empleado");
		conexionBD = conectar.conexion();
		System.out.println("usuario: " + usuario);
		System.out.println("clave: " + clave);

		if (verificarLogin(usuario, clave)) {
			System.out.print("los datos fueron verificados");
			this.Login.setVisible(false); // hago desaparecer el login
			this.setVisible(true); // hago aparecer el empleadoVentana
			legajo = usuario;
			try {
				stmt = this.conexionBD.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}

			return true;
		} else
			return false;

	}

	/**
	 * Selecciona una o mas cuotas de la tabla y actualiza la base de datos
	 * agregandola como paga
	 * 
	 */
	private void abonarCuotas() {
		if (MostrarCuotasImpaga()) {
			
			
			
			int cuotaSeleccionada = tabla.getSelectedRow();

			if (cuotaSeleccionada == -1)// No hay ninguna seleccionada
				return;

			
			int dialogButton = 0;
			int dialogResult = JOptionPane.showConfirmDialog(null,
					"�Desea pagar cuota seleccionada?", "Warning", dialogButton);
			if (dialogResult == JOptionPane.YES_OPTION) {
					
			int cantTuplas = tabla.getSelectedRowCount();
			try {
				int a = cuotaSeleccionada;
				Statement s = conexionBD.createStatement();

				for (int i = cuotaSeleccionada; i < a + cantTuplas; i++)
					s.execute("UPDATE pago SET fecha_pago=curdate() where nro_prestamo=" + nro_prestamo
							+ " and nro_pago=" + tabla.getTable().getValueAt(i, 0));

				s.close();
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}

			MostrarCuotasImpagas();
			
			
		}//del si del confirm dialog
	
		
		}//del si del cuotas impagas
		
			 else 
				{JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
						"Error al ingresar los datos del cliente o bien el cliente no tiene cuotas impagas " + "\n", "Error", JOptionPane.INFORMATION_MESSAGE);
				}
	
	}

	/**
	 * Determina si existe un prestamo vigente para un cliente determinado. Si
	 * existe un prestamo vigente devuelve este sino devuelve menos uno, que
	 * indica que no tiene prestamos vigentes
	 * 
	 */
	private int obtenerPrestamoActivo() {
		int prestamo = -1;

		int[] prestamos = new int[100];
		try {

			cliente = Obtenercliente(NroDoc.getText(), TipoDoc.getText());

			if (cliente != "") {

				String prestamosDelCliente = "select nro_prestamo from prestamo where nro_cliente='" + cliente + "';";
				ResultSet resultadoPrestamosDelcliente = stmt.executeQuery(prestamosDelCliente);
				int i = 0;
				// guardo todos los prestamos del usuario
				while (resultadoPrestamosDelcliente.next()) {
					if (i < 99)
						prestamos[i] = resultadoPrestamosDelcliente.getInt(1);
					i++;
				}
				if (i < 99)
					prestamos[i] = -1;
				resultadoPrestamosDelcliente.close();
				i = 0;
				while (prestamos[i] != -1) {
					// Si hay alg�n pago con fecha_pago null significa que no
					// pag� todas las cuotas de ese pr�stamo
					String consultaDeLosPagosDelPrestamo = "select nro_pago from pago where nro_prestamo='"
							+ prestamos[i] + "' and fecha_pago is null;";
					ResultSet rs3 = stmt.executeQuery(consultaDeLosPagosDelPrestamo);
					if (rs3.next())
						prestamo = prestamos[i];
					rs3.close();
					i++;

				}

			}
			return prestamo;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return prestamo;

	}

	/**
	 * Muestra el listado de las cuotas impagas del prestamo vigente de un
	 * determinado cliente
	 * 
	 */
	private void MostrarCuotasImpagas() {

		try {
			if (!NroDoc.getText().equals("") && !TipoDoc.equals("")) {
				nro_prestamo = obtenerPrestamoActivo();

				System.out.println("los datos son " + NroDoc.getText());
				String sql21 = "SELECT nro_pago, fecha_venc, valor_cuota FROM pago JOIN prestamo ON pago.nro_prestamo=prestamo.nro_prestamo WHERE pago.nro_prestamo="
						+ nro_prestamo + " AND fecha_pago is NULL";

				ResultSet rs = stmt.executeQuery(sql21);
				tabla.refresh(rs);

				if (rs.getRow() == 0) {
					// tabla.close();
					tabla.enable(false);
				}

				rs.close();
				// actualiza el contenido de la tabla con los datos del resul
				// set rs

				if (tabla.getColumnByDatabaseName("fecha_venc") != null) {
					tabla.getColumnByDatabaseName("fecha_venc").setDateFormat("dd/MM/YYYY");
					tabla.getColumnByDatabaseName("fecha_venc").setMinWidth(80);
				}

				else
					stmt.executeUpdate(sql21);

			} else

			{

				JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this),
						"Error al ingresar los datos del cliente " + "\n", "Error", JOptionPane.INFORMATION_MESSAGE);
			}

		} catch (SQLException ex) {

			// en caso de error, se muestra la causa en la consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Error al ejecutar la consulta o el insert", JOptionPane.INFORMATION_MESSAGE);
		}

	}

	/**
	 * Muestra el listado de clientes que se han atrasado en al menos 2 cuotas
	 * de su prestam, esto es, si existen al menos dos cuotas impagas cuya fecha
	 * de vencimiento sea menor a la fecha actual
	 * 
	 */
	private void mostrarMorosos() {

		try {

			ResultSet rs = stmt.executeQuery(
					"SELECT nro_cliente, tipo_doc, nro_doc, nombre, apellido, nro_prestamo, monto, cant_meses, valor_cuota, count(nro_pago) as cant_cuotas "
							+ "FROM cliente NATURAL JOIN prestamo NATURAL JOIN pago "
							+ "WHERE fecha_pago IS NULL"
							+ " AND fecha_venc < CURDATE() " + "GROUP BY nro_prestamo "
							+ "HAVING cant_cuotas>=2;");

			//System.out.println(" la consulta es "+rs);
			
			
			if (rs == null)
				tabla.cleanup();
			else {
				tabla.refresh(rs);
				System.out.println("La consulta obtiene resultados");
			}
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * Determina si el cliente tiene cuotas impagas
	 */
	private boolean MostrarCuotasImpaga() {
		boolean tiene = false;
		try {

			if (NroDoc.getText() != null && TipoDoc.getText() != null) {
				nro_prestamo = obtenerPrestamoActivo();
				if (nro_prestamo != -1) {

					String consultaCuotasImpagas = "SELECT nro_pago, fecha_venc, valor_cuota FROM pago JOIN prestamo ON pago.nro_prestamo=prestamo.nro_prestamo WHERE pago.nro_prestamo="
							+ nro_prestamo + " AND fecha_pago is NULL";

					ResultSet rs = stmt.executeQuery(consultaCuotasImpagas);

					if (rs.next())
						tiene = true;
					;

					rs.close();
					// actualiza el contenido de la tabla con los datos del
					// resul set rs

					if (tabla.getColumnByDatabaseName("fecha_venc") != null) {
						tabla.getColumnByDatabaseName("fecha_venc").setDateFormat("dd/MM/YYYY");
						tabla.getColumnByDatabaseName("fecha_venc").setMinWidth(80);
					}

					else
						stmt.executeUpdate(consultaCuotasImpagas);
				}
			}

		} catch (SQLException ex) {

			// en caso de error, se muestra la causa en la consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "por favor oprima cuotas impagas primero" + "\n", "Error .",
					JOptionPane.INFORMATION_MESSAGE);
		}

		return tiene;
	}

	public void IntroducirMonto() {
		if (puedeGenerarPrestamo()) {
			System.out.println("pudo generar prestamo ");

			try {
				if (montotf.getText() != null) {

					String monto = montotf.getText();

					String sql = "select periodo,tasa from Tasa_Prestamo where  monto_inf<='" + monto
							+ "' and monto_sup>='" + monto + "';";

					ResultSet rs = stmt.executeQuery(sql);

					DefaultListModel modelo = new DefaultListModel();

					if (rs.next()) {
						System.out.println("la consulta " + sql + " dio resultados ");

						rs.beforeFirst();
						while (rs.next()) {
							modelo.addElement(rs.getString("periodo"));
						}

						listaDeCuotas.setModel(modelo);
						listaDeCuotas.setVisible(true);
						rs.close();
						listaDeCuotas.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
						listaDeCuotas.addListSelectionListener(new ListSelectionListener() {
							@Override
							public void valueChanged(ListSelectionEvent arg0) {
								if (!arg0.getValueIsAdjusting()) {
									if (!listaDeCuotas.isSelectionEmpty()) {
										int dialogButton = 0;
										int dialogResult = JOptionPane.showConfirmDialog(null,
												"�Desea confirmar Prestamo?", "Warning", dialogButton);
										if (dialogResult == JOptionPane.YES_OPTION) {
											// Saving code here
											a�adirPrestamo(listaDeCuotas.getSelectedValue().toString(), monto);
											listaDeCuotas.setVisible(false);
										}

									}
								}
							}
						});
					} else if (monto != null)
						JOptionPane.showMessageDialog(null, "No es posible generar prestamo de: " + monto + "");

				}
			} catch (SQLException ex) {

				JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
						"Error al ingresar monto.", JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}

}
