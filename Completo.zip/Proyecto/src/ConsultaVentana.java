
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentEvent;
import java.beans.PropertyVetoException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.BevelBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import quick.dbtable.*;

/**
 * Se encarga de todo lo relacionado a la ventana de operaciones y logueo del
 * admin
 */
@SuppressWarnings("serial")
public class ConsultaVentana extends javax.swing.JInternalFrame implements Ventana {
	private JPanel pnlConsulta;
	private JTextArea txtConsulta;
	private JButton botonBorrar;
	private JButton btnEjecutar;
	private DBTable tabla;
	private JScrollPane scrConsulta;
	private SuscripcionVentana Login;
	private JPanel jPanel1;
	private BaseDeDatos conectar;
	protected Connection conexionBD = null;
	private JScrollPane scrollPane;
	private JList listaDeTablas;
	private JScrollPane scrollPane_1;
	private JList listaDeAtributos;
	private Statement stmt;

	private JScrollPane scrollPaneTabla;

	/**
	 * Crea lo necesario para armar la ventana.
	 * 
	 * @param panel
	 */
	public ConsultaVentana(JPanel panel) {
		super();
		setTitle("Banco - Administrador");
		initGUI();
		jPanel1 = panel;
	}

	/**
	 * Se encarga de armar la ventana del logueo del admin
	 */
	public void suscripcion() {
		setClosable(true);
		this.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
		Login = new SuscripcionVentana(this);
		Login.setBounds(170, 20, 650, 400);
		this.Login.setVisible(true);
		Login.setTitulo("Banco - Login Administrador");
		Login.setSegundaEtiqueta("Password");
		Login.setVisiblePrimeraEtiqueta(false);
		Login.setVisiblePrimerTxt(false);

		jPanel1.add(this.Login);
		try {
			Login.setSelected(true);
		} catch (PropertyVetoException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Inicializa la ventana para las consultas del administrador.
	 */
	private void initGUI() {
		try {
			// Creacion de la ventana
			setPreferredSize(new Dimension(990, 475));
			this.setBounds(10, 50, 1050, 475);
			setVisible(false);
			this.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);

			this.setMaximizable(true);

			getContentPane().setLayout(null);
			getContentPane().setBackground(new Color(0, 204, 51));

			{
			
				pnlConsulta = new JPanel();
				pnlConsulta.setBounds(0, 0, 784, 186);
				pnlConsulta.setBackground(new Color(0, 204, 51));
				getContentPane().add(pnlConsulta);
				{
					scrConsulta = new JScrollPane();
					pnlConsulta.add(scrConsulta);
					{
						txtConsulta = new JTextArea();
						scrConsulta.setViewportView(txtConsulta);
						txtConsulta.setTabSize(3);
						txtConsulta.setColumns(80);
						txtConsulta.setBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED));
						txtConsulta.setFont(new java.awt.Font("Monospaced", 0, 12));
						txtConsulta.setRows(10);
					}
				}
				{
					btnEjecutar = new JButton();
					pnlConsulta.add(btnEjecutar);
					btnEjecutar.setText("Ejecutar");

					btnEjecutar.setFont(new Font("Tahoma", Font.BOLD, 11));
					btnEjecutar.setBackground(new Color(0, 204, 51));
					btnEjecutar.setForeground(new Color(0, 0, 0));

					btnEjecutar.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent evt) {
							btnEjecutarActionPerformed(evt);
						}
					});
				}
				{
					botonBorrar = new JButton();
					pnlConsulta.add(botonBorrar);
					botonBorrar.setText("Borrar");

					botonBorrar.setFont(new Font("Tahoma", Font.BOLD, 11));
					botonBorrar.setBackground(new Color(0, 204, 51));
					botonBorrar.setForeground(new Color(0, 0, 0));

					botonBorrar.addActionListener(new ActionListener() {
						public void actionPerformed(ActionEvent arg0) {
							txtConsulta.setText("");
						}
					});
				}
			}

			{
				// crea un ScrollPane
				scrollPaneTabla = new JScrollPane();
				scrollPaneTabla.setBounds(50, 349, 900, 321);
				scrollPaneTabla.setBackground(new Color(0, 204, 51));

				// crea la tabla
				tabla = new DBTable();
				tabla.setBounds(50, 349, 900, 321);
				tabla.setBackground(new Color(0, 204, 51));
			
				tabla.setEditable(false);

				getContentPane().add(scrollPaneTabla);

				scrollPaneTabla.setViewportView(tabla);
			}
			{
				scrollPane = new JScrollPane();
				scrollPane.setBounds(102, 220, 150, 100);
				scrollPane.setBackground(new Color(0, 204, 51));

				getContentPane().add(scrollPane);
				{
					listaDeTablas = new JList();
					scrollPane.setViewportView(listaDeTablas);
				}
			}
			{
				scrollPane_1 = new JScrollPane();
				scrollPane_1.setBounds(336, 220, 150, 100);
				getContentPane().add(scrollPane_1);
				{
					listaDeAtributos = new JList();
					scrollPane_1.setViewportView(listaDeAtributos);
				}
			}
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Evento para desconectarse de la BD.
	 * 
	 * @param evt
	 */
	private void thisComponentHidden(ComponentEvent evt) {
		this.desconectarBD();
	}

	/**
	 * Evento para refrescar la tabla.
	 * 
	 * @param evt
	 */
	private void btnEjecutarActionPerformed(ActionEvent evt) {
		this.refrescarTabla();
	}

	/**
	 * Realiza la desconexion de la base de datos.
	 */
	private void desconectarBD() {
		try {
			tabla.close();
		} catch (SQLException ex) {
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
		}
	}

	/**
	 */
	private void refrescarTabla() {
		String sql = txtConsulta.getText();

		try {
			if (sql.startsWith("select") || sql.startsWith("Select") || sql.startsWith("SELECT")) {
				ResultSet rs = stmt.executeQuery(sql);

				// actualiza el contenido de la tabla con los datos del resul
				// set rs
				tabla.refresh(rs);

				if (tabla.getColumnByDatabaseName("hora") != null) {
					tabla.getColumnByDatabaseName("hora").setDateFormat("hh:mm:ss");
					tabla.getColumnByDatabaseName("hora").setMinWidth(80);
				}
				if (tabla.getColumnByDatabaseName("fecha") != null) {
					tabla.getColumnByDatabaseName("fecha").setDateFormat("dd/MM/YYYY");
					tabla.getColumnByDatabaseName("fecha").setMinWidth(80);
				}
			} else {

				System.out.println("Update o Insert");
				stmt.executeUpdate(sql);
				JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "Se modificaron/actualizaran datos \n",
						"Cambios en la BD", JOptionPane.INFORMATION_MESSAGE);

			}
		} catch (SQLException ex) {
			// en caso de error, se muestra la causa en la consola
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), "Error al ejecutar la consulta o ejecutando un insert." + "\n",
					"Consulta erronea", JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Muesta en un JScrollPane, las distintas tablas de la base de datos.
	 */
	public void TablasDeLaBaseDeDatos() {
		try {
			Statement stmt = this.conexionBD.createStatement();
			String sql = "show tables";
			ResultSet rs = stmt.executeQuery(sql);
			DefaultListModel modelo = new DefaultListModel();
			while (rs.next()) {
				modelo.addElement(rs.getString("Tables_in_banco"));
			}
			listaDeTablas.setModel(modelo);
			listaDeTablas.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
			listaDeTablas.addListSelectionListener(new ListSelectionListener() {
				@Override
				public void valueChanged(ListSelectionEvent arg0) {
					if (!arg0.getValueIsAdjusting()) {
						mostrarAtributosTabla(listaDeTablas.getSelectedValue().toString());
					}
				}
			});
		} catch (SQLException ex) {
			// en caso de error, se muestra la causa en la consola
			System.out.println("SQLException: " + ex.getMessage());
			System.out.println("SQLState: " + ex.getSQLState());
			System.out.println("VendorError: " + ex.getErrorCode());
			JOptionPane.showMessageDialog(SwingUtilities.getWindowAncestor(this), ex.getMessage() + "\n",
					"Error al ejecutar la consulta.", JOptionPane.ERROR_MESSAGE);
		}
	}

	/**
	 * Muestra en un JScrollPane, los distintos atributos de una tabla de la
	 * base de datos.
	 * 
	 * @param tabla
	 *            De la cual se mostraran los atributos.
	 */
	public void mostrarAtributosTabla(String tabla) {
		try {
			String sql = "DESCRIBE " + tabla;
			ResultSet rs;
			rs = stmt.executeQuery(sql);
			DefaultListModel modelo = new DefaultListModel();
			while (rs.next()) {
				modelo.addElement(rs.getString("Field"));
			}
			listaDeAtributos.setModel(modelo);
			listaDeAtributos.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Realiza la conexion del administrador con la base de datos.
	 */
	public boolean ingresarAlaBD(String clave, String usuario) {
		conectar = new BaseDeDatos(tabla);
		conectar.conectarBaseDatos(clave, "admin");
		conexionBD = conectar.conexion();
		if (conexionBD != null) {
			this.Login.setVisible(false);
			this.setVisible(true);
			// muestra las tablas al logearse
			TablasDeLaBaseDeDatos();
			try {
				stmt = this.conexionBD.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return true;
		} else {
			return false;
		}
	}

}
