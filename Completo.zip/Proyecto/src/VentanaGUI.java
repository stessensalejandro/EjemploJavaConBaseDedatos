import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.beans.PropertyVetoException;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JToggleButton;
import javax.swing.JList;
import javax.swing.JRadioButton;
import javax.swing.JPanel;

public class VentanaGUI extends javax.swing.JFrame {

	private JFrame frmProgramaBanco;
	private JPanel panel;

	private ConsultaVentana ventanaAdmin;
	private ATMVentana ventanaATM;
	private EmpleadoVentana ventanaEmpleado;

	private JButton btnSalir;
	private JButton btnAtm;
	private JButton btnAdmin;
	private JButton btnEmpleado;
	private JButton btnMenu;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaGUI window = new VentanaGUI();
					window.frmProgramaBanco.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaGUI() {
		initialize();

		this.ventanaATM = new ATMVentana(panel);
		this.ventanaATM.setVisible(false);
		this.panel.add(this.ventanaATM);

		this.ventanaEmpleado = new EmpleadoVentana(panel);
		this.ventanaEmpleado.setVisible(false);
		this.panel.add(this.ventanaEmpleado);

		this.ventanaAdmin = new ConsultaVentana(panel);
		this.ventanaAdmin.setVisible(false);
		this.panel.add(this.ventanaAdmin);

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmProgramaBanco = new JFrame();
		frmProgramaBanco.setBackground(Color.CYAN);
		frmProgramaBanco.setTitle("Programa Banco");
		frmProgramaBanco.setBounds(100, 100, 1024, 600);
		frmProgramaBanco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmProgramaBanco.getContentPane().setLayout(null);

		btnSalir = new JButton("Salir");
		btnSalir.setBackground(new Color(255, 0, 0));
		btnSalir.setBounds(450, 530, 89, 32);

		frmProgramaBanco.getContentPane().add(btnSalir);
		btnSalir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				SalirActionPerformed(evt);
			}
		});

		btnMenu = new JButton("MENU");
		btnMenu.setBackground(new Color(0, 204, 51));
		btnMenu.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnMenu.setForeground(new Color(0, 0, 0));
		btnMenu.setBounds(450, 11, 125, 39);
		frmProgramaBanco.getContentPane().add(btnMenu);
		btnMenu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				removerPanel();
				MenuActionPerformed(evt);
			}
		});

		panel = new JPanel();
		panel.setBounds(10, 50, 990, 600);
		frmProgramaBanco.getContentPane().add(panel);
		panel.setLayout(null);

		btnAtm = new JButton("ATM");
		btnAtm.setBounds(150, 73, 100, 50);
		panel.add(btnAtm);
		btnAtm.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAtm.setBackground(new Color(0, 204, 51));
		btnAtm.setForeground(new Color(0, 0, 0));
		btnAtm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				ATMActionPerformed(evt);
			}
		});

		btnEmpleado = new JButton("Empleado");
		btnEmpleado.setBounds(775, 73, 100, 50);
		panel.add(btnEmpleado);
		btnEmpleado.setForeground(Color.BLACK);
		btnEmpleado.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnEmpleado.setBackground(new Color(0, 204, 51));
		btnEmpleado.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				EmpleadoActionPerformed(evt);
			}
		});

		btnAdmin = new JButton("Admin");
		btnAdmin.setBounds(450, 73, 100, 50);
		panel.add(btnAdmin);
		btnAdmin.setForeground(Color.BLACK);
		btnAdmin.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnAdmin.setBackground(new Color(0, 204, 51));
		btnAdmin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				AdminActionPerformed(evt);
				
			}
		});

		this.setSize(1024, 600);
		pack();
	}

	/**
	 * oyente para el logueo como admin.
	 * 
	 * @param evt
	 */
	private void AdminActionPerformed(ActionEvent evt) {
		try {
			this.ventanaAdmin.setMaximum(true);
		} catch (PropertyVetoException e) {
		}
		btnEmpleado.setVisible(false);
		btnAdmin.setVisible(false);
		btnAtm.setVisible(false);
		ventanaAdmin.suscripcion();
		
		
	}

	// crea el menu
	private void MenuActionPerformed(ActionEvent evt) {
		try {

			this.ventanaATM.setMaximum(true);
		} catch (PropertyVetoException e) {
		}
		btnEmpleado.setVisible(true);
		btnAdmin.setVisible(true);
		btnAtm.setVisible(true);
	}

	// crea el login de atm
	private void ATMActionPerformed(ActionEvent evt) {
		try {

			this.ventanaATM.setMaximum(true);
		} catch (PropertyVetoException e) {
		}
		btnEmpleado.setVisible(false);
		btnAdmin.setVisible(false);
		btnAtm.setVisible(false);
		this.ventanaATM.suscripcion();
	}

	// crea el login de empleado
	private void EmpleadoActionPerformed(ActionEvent evt) {
		try {
			this.ventanaEmpleado.setMaximum(true);
		} catch (PropertyVetoException e) {
		}
		btnEmpleado.setVisible(false);
		btnAdmin.setVisible(false);
		btnAtm.setVisible(false);
		this.ventanaEmpleado.suscripcion();
	}

	private void SalirActionPerformed(ActionEvent evt) {
		frmProgramaBanco.dispose();
	}
	
	private void removerPanel() {
		Component[] d = panel.getComponents();
		for(int index=0;index<d.length;index++){
				d[index].setVisible(false);
			}
		}
	
}
